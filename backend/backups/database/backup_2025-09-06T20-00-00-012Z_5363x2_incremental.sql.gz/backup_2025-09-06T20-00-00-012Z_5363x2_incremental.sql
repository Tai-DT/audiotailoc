
      -- Incremental backup for tables: _prisma_migrations, campaign_clicks, campaign_opens, campaign_recipients, campaigns, cart_items, carts, categories, chat_messages, chat_sessions, customer_questions, email_logs, inventory, knowledge_base_entries, loyalty_accounts, loyalty_rewards, notifications, order_items, orders, pages, payment_intents, payments, point_transactions, product_review_reports, product_review_votes, product_reviews, product_views, products, projects, promotions, redemption_history, search_queries, service_booking_items, service_bookings, service_items, service_payments, service_status_history, service_views, services, system_configs, technician_schedules, technicians, users, webhooks, wishlist_items
      -- Since: 2025-09-05T20:00:00.012Z

      -- Note: This is a basic implementation
      -- For production use, consider PostgreSQL PITR or logical replication

      SELECT 'Incremental backup created on: ' || now() as info;
    