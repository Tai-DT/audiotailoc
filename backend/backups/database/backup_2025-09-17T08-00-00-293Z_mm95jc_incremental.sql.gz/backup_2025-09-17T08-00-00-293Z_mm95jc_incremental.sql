
      -- Incremental backup for tables: refunds, categories, contact_messages, site_settings, wishlist_items, product_reviews, product_review_votes, product_review_reports, search_queries, product_views, service_views, customer_questions, service_items, service_bookings, technicians, service_booking_items, technician_schedules, service_status_history, service_payments, loyalty_accounts, point_transactions, redemption_history, loyalty_rewards, knowledge_base_entries, projects, activity_logs, campaigns, campaign_recipients, campaign_opens, campaign_clicks, email_logs, software, _prisma_migrations, inventory_reports, pages, promotions, banners, system_configs, webhooks, products, users, carts, cart_items, orders, order_items, payments, payment_intents, service_types, services, notifications, inventory, inventory_movements, inventory_alerts
      -- Since: 2025-09-16T08:00:00.293Z

      -- Note: This is a basic implementation
      -- For production use, consider PostgreSQL PITR or logical replication

      SELECT 'Incremental backup created on: ' || now() as info;
    