
      -- Incremental backup for tables: _prisma_migrations, messages, conversations, inventory_reports, pages, banners, system_configs, promotions, webhooks, users, carts, orders, payments, payment_intents, service_types, services, inventory, inventory_movements, inventory_alerts, product_review_votes, product_review_reports, search_queries, product_views, service_views, service_bookings, technicians, service_booking_items, technician_schedules, service_status_history, service_payments, loyalty_accounts, point_transactions, redemption_history, loyalty_rewards, projects, activity_logs, campaign_recipients, campaign_opens, campaigns, campaign_clicks, email_logs, knowledge_base_entries, service_items, customer_questions, refunds, cart_items, notifications, categories, order_items, product_reviews, products, wishlist_items, newsletter_subscriptions, policies, site_settings, site_stats, software, testimonials, blog_articles, blog_categories, blog_comments, email_templates
      -- Since: 2025-11-22T12:00:00.301Z

      -- Note: This is a basic implementation
      -- For production use, consider PostgreSQL PITR or logical replication

      SELECT 'Incremental backup created on: ' || now() as info;
    