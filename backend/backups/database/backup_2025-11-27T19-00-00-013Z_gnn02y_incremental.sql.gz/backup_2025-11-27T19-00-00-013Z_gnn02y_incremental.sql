
      -- Incremental backup for tables: support_tickets, campaign_promotions, campaign_metrics, project_promotion_reviews, _prisma_migrations, inventory_reports, pages, promotions, banners, system_configs, webhooks, carts, users, projects, service_bookings, orders, product_review_votes, payments, payment_intents, service_types, services, inventory, inventory_movements, inventory_alerts, product_review_reports, search_queries, product_views, service_views, technicians, service_booking_items, technician_schedules, service_status_history, service_payments, loyalty_accounts, point_transactions, redemption_history, loyalty_rewards, activity_logs, campaign_recipients, campaign_opens, campaign_clicks, email_logs, campaigns, cart_items, refunds, categories, customer_questions, knowledge_base_entries, notifications, order_items, product_reviews, products, service_items, wishlist_items, newsletter_subscriptions, policies, site_settings, site_stats, software, testimonials, blog_articles, blog_categories, blog_comments, email_templates, promotion_analytics, messages, conversations, promotions_products, promotions_categories, customer_promotions, promotion_audit_logs, promotion_versions
      -- Since: 2025-11-26T19:00:00.013Z

      -- Note: This is a basic implementation
      -- For production use, consider PostgreSQL PITR or logical replication

      SELECT 'Incremental backup created on: ' || now() as info;
    